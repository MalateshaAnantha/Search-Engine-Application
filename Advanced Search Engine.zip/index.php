<?php
// make sure browsers see this page as utf-8 encoded HTML
ini_set('memory_limit','3G');
header('Content-Type: text/html; charset=utf-8');
include 'SpellCorrector.php';
include 'functions.php';

$limit = 10;
$additional_params= array(
 'sort' => 'pageRankFile desc'
	);
$query = isset($_REQUEST['q']) ? $_REQUEST['q'] : false;
$results = false;
$parts = preg_split('/\s+/', $query);
$results_custom=false;
$overlap = false;
$newquery = "";
$fileUrlMap = array();
if ($query)
{
 // The Apache Solr Client library should be on the include path
 // which is usually most easily accomplished by placing in the
 // same directory as this script ( . or current directory is a default
 // php include path entry in the php.ini)
 require_once('solr-php-client/Apache/Solr/Service.php');
 // create a new solr service instance - host, port, and corename
 // path (all defaults in this example)
 $solr = new Apache_Solr_Service('localhost', 8983, '/solr/myexample/');
 // if magic quotes is enabled then stripslashes will be needed
 if (get_magic_quotes_gpc() == 1)
 {
 $query = stripslashes($query);
 }
 // in production code you'll always want to use a try /catch for any
 // possible exceptions emitted by searching (i.e. connection
 // problems or a query parsing error)
 try
 {
 $results = $solr->search($query, 0, $limit);
 $results_custom = $solr->search($query, 0, $limit, $additional_params);
if($results && $results_custom){
$overlap = 0;

$handle = fopen("Boston_Global_Map.csv", "r");
#$handle = fopen("mapLATimesDataFile.csv", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
        // process the line read.
	
	$values = preg_split("/,/",$line);
	$fileUrlMap[$values[0]]=$values[1];
    }

    fclose($handle);
} else {
    // error opening the file.
	echo "Error opeining Boston_Global_Map.csv";
} 


foreach ($results->response->docs as $doc)
 {foreach ($results_custom->response->docs as $doc2)

	
	if($doc->id == $doc2->id)
	$overlap++;

}


}
 }
 catch (Exception $e)
 {
 // in production you'd probably log or email this error to an admin
 // and then show a special message to the user but for this example
 // we're going to show the full exception
 die("<html><head><title>SEARCH EXCEPTION</title><body><pre>{$e->__toString()}</pre></body></html>");
 }
}


?>
<html>
 <head>
 <title>PHP Solr Client Example</title>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
 <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
   
    $( "#q" ).autocomplete({
      source: function( request, response ) {

	 var last = request.term.toLowerCase().trim().split(" ").pop(-1);
        $.ajax( {
          url: "http://localhost:8983/solr/myexample/suggest",
          dataType: "jsonp",
	'jsonp': 'json.wrf',
          data: {
            "q":last,
			"wt":"json"
		
          },
          success: function( data ) {
			 // console.log(data);
		var last = $("#q").val().toLowerCase().trim().split(" ").pop(-1);
		arr = []
		data.suggest.suggest[last].suggestions.forEach(function(item){

			var next = "";
                                var queries = $("#q").val().trim().split(" ");
                                
				if (queries.length > 1) {
                                    var index = $("#q").val().trim().lastIndexOf(" ");
                                    next = $("#q").val().trim().substring(0, index + 1).toLowerCase();
                                }
				if (!/^[a-zA-Z]+$/.test(item.term)) {
                                    return;
                                }
				if(/(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9]\.[^\s]{2,})/.test(item.term)){
				return;					
					}


				arr.push(next + item.term)
			})
            response( arr );
          }
        } );
      }
    });
  } );
  </script>

<style>
form{
text-align: center;
margin-top:35px;
}
.type{
font-size:2em;

}
</style> 
</head>
 <body>
<div class="container-fluid">
 <form class="form-inline" accept-charset="utf-8" method="get">
 <div class="form-group">
 <label for="q">Enter Query:</label>
<input id="q" name="q" type="text" class="form-control" placeholder="" value="<?php echo htmlspecialchars($query, ENT_QUOTES, 'utf-8'); ?>"/>
 <!--<input id="q" name="q" type="text" value="<?php echo htmlspecialchars($query, ENT_QUOTES, 'utf-8'); ?>"/>-->
 
</div>
<button type="submit" class="btn btn-default"> <span class="glyphicon glyphicon-search" aria-hidden="true"></span> Search </button>
 </form>

<div class="container" style="font-size: 20px;"><?php 
$flag = false;
foreach($parts as $str){

$correct = SpellCorrector::correct($str);
$newquery = $newquery." ".$correct; 
if($correct != $str)
$flag = true;
}
if($flag)
echo '<div class="well well-sm"> Did you mean: '.'<a href="index.php?q='.trim($newquery).'">'.$newquery.'</a></div>';
?>

</div>
<div class="container-fluid">

<?php
// display results
if ($overlap)
{
?>
<h3>Overlap Results <span class="label label-warning"><?php echo $overlap; ?></span></h3>
<?php
}
?>
<div class="row">
<div class="col-md-6">

<?php
// display results
if ($results)
{
 $total = (int) $results->response->numFound;
 $start = min(1, $total);
 $end = min($limit, $total);
?>
 <div><span class="type" style="background-color:goldenrod;">Default Lucene Results </span><?php echo $start; ?> - <?php echo $end;?> of <?php echo $total; ?>:</div>
 <!--<ol>-->
<div class="row">
<?php
 // iterate result documents
 foreach ($results->response->docs as $doc)
 {
#$url = urldecode($doc->og_url);
$temp = preg_split("/\//",$doc->id);
$temp = array_reverse($temp);
$url= $fileUrlMap[$temp[0]];
$title = $doc->title? $doc->title : "Title Not Available";
$description = $doc->description? $doc->description : "Description Not Available";
$filecontent = file_get_contents("/home/malatesha/solr-7.1.0/CrawlData/BG/BG/".$temp[0]);
$lines = explode(PHP_EOL,$filecontent);
//echo $lines[0];
$words = preg_split('/\s+/', $query);


?>
 <!--<li>
 <table style="border: 1px solid black; text-align: left">-->
<div class="col-md-12">
<h3><a target="_blank" href="<?php echo htmlspecialchars(urldecode($url), ENT_NOQUOTES, 'utf-8'); ?>" ><?php echo htmlspecialchars($title, ENT_NOQUOTES, 'utf-8'); ?></a></h3>
<h6><a target="_blank" href="<?php echo htmlspecialchars(urldecode($url), ENT_NOQUOTES, 'utf-8'); ?>"><?php echo htmlspecialchars(urldecode($url), ENT_NOQUOTES, 'utf-8'); ?></a></h6>
<p><b>Description :-</b><?php echo htmlspecialchars($description, ENT_NOQUOTES, 'utf-8'); ?></p>
<h6>ID :- <?php echo htmlspecialchars($doc->id, ENT_NOQUOTES, 'utf-8'); ?></h6>

<p><b>Snippet:-</b> <?php $content = getSnippet($words, $doc->id);
                  $content = decorateSnippet($words,$content);
                  echo empty($content) ? "Not available" : $content; ?></p>
<a></a>
<!--<?php
 // iterate document fields / values
 foreach ($doc as $field => $value)
 {
?>
 <tr>
 <th><?php echo htmlspecialchars($field, ENT_NOQUOTES, 'utf-8'); ?></th>
 <td><?php echo htmlspecialchars($value, ENT_NOQUOTES, 'utf-8'); ?></td>
 </tr>
<?php
 }
?>-->
</div>
<!-- </table>

</li>-->
<?php
 }
?>
</div>
 <!--</ol>-->
<?php
}
?>
</div>
<div class="col-md-6">

<?php
// display results
if ($results_custom)
{
 $total = (int) $results_custom->response->numFound;
 $start = min(1, $total);
 $end = min($limit, $total);
?>
 <div><span class="type" style="background-color:aquamarine;"> PageRank Results </span><?php echo $start; ?> - <?php echo $end;?> of <?php echo $total; ?>:</div>
 <div class="row">
<?php
 // iterate result documents
 foreach ($results_custom->response->docs as $doc)
 {
#$url = urldecode($doc->og_url);
$temp = preg_split("/\//",$doc->id);
$temp = array_reverse($temp);
$url= $fileUrlMap[$temp[0]];
$title = $doc->title? $doc->title : "Title Not Available";
$description = $doc->description? $doc->description : "Description Not Available";
$filecontent = file_get_contents("/home/malatesha/solr-7.1.0/CrawlData/BG/BG/".$temp[0]);
$lines = explode(PHP_EOL,$filecontent);
//echo $lines[0];
$words = preg_split('/\s+/', $query);
?>
 <!--<li>
 <table style="border: 1px solid black; text-align: left">-->
<div class="col-md-12">
<h3><a target="_blank" href="<?php echo htmlspecialchars($url, ENT_NOQUOTES, 'utf-8'); ?>" ><?php echo htmlspecialchars($title, ENT_NOQUOTES, 'utf-8'); ?></a></h3>
<h6><a target="_blank" href="<?php echo htmlspecialchars(urldecode($url), ENT_NOQUOTES, 'utf-8'); ?>"><?php echo htmlspecialchars(urldecode($url), ENT_NOQUOTES, 'utf-8'); ?></a></h6>
<p><b>Description :-</b><?php echo htmlspecialchars($description, ENT_NOQUOTES, 'utf-8'); ?></p>
<h6>ID :- <?php echo htmlspecialchars($doc->id, ENT_NOQUOTES, 'utf-8'); ?></h6>

<p><b>Snippet:-</b> <?php $content = getSnippet($words, $doc->id);
                  $content = decorateSnippet($words,$content);
                  echo empty($content) ? "Not available" : $content; ?></p>
<a></a>
<!--<?php
 // iterate document fields / values
 foreach ($doc as $field => $value)
 {
?>
 <tr>
 <th><?php echo htmlspecialchars($field, ENT_NOQUOTES, 'utf-8'); ?></th>
 <td><?php echo htmlspecialchars($value, ENT_NOQUOTES, 'utf-8'); ?></td>
 </tr>
<?php
 }
?>-->
</div>
<!-- </table>

</li>-->
<?php
 }
?>
</div>
<?php
}
?>
</div>
</div>
</div>
</div>

 </body>
</html>

